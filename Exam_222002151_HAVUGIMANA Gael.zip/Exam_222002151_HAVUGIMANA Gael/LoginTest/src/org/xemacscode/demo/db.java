 
package org.xemacscode.demo;

//Database connection

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class db {
    
    public static Connection mycon(){
        Connection con= null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/dbtest","kivu","kivu");
            
        }catch(ClassNotFoundException | SQLException e){
            
            System.out.print(e);
        }
    return con;  
    }
    
}
