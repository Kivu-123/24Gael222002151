-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 09:53 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtest`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `User_id` int(25) NOT NULL,
  `First Name` varchar(25) NOT NULL,
  `Second Name` varchar(25) NOT NULL,
  `Address` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`User_id`, `First Name`, `Second Name`, `Address`, `username`, `password`) VALUES
(1, 'Ruzigana', 'Jean', 'Gasabo', 'Jean', 'admin'),
(2, 'Don', 'Mufasa', 'Gisagara', 'Don', 'admin'),
(4, 'Alex', 'Andre', 'Gasabo', 'Alex', 'admin'),
(5, 'Yussuf', 'Noheli', 'Nyanza', 'Yussuf', 'admin'),
(6, 'Nadia', 'Fati', 'Nyaruguru', 'Nadia', 'admin'),
(7, 'Eddie', 'Aime', 'Nyabihu', 'Aime', 'admin'),
(8, 'Gael', 'HAVUGIMANA', '222002151', 'Gael', '222002151');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`User_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `User_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
